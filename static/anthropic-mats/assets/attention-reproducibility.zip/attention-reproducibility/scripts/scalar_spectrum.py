"""Recompute the fixed-value depth-four scalar spectrum at 110 digits."""
import argparse, json, math
from pathlib import Path
import mpmath as mp
mp.mp.dps=110

def scalar_jacobian_spectrum():
    """High-precision spectrum of raw scalar Q/K Jacobian, fixed unit values."""
    result=[]
    for order,depth in [(1,4)]:
        probes=[mp.mpf('.45')+mp.mpf('.2')*j for j in range(depth)]
        scales=[mp.mpf(v) for v in ['.08','.04','.02']]
        sigmas=[]; tied=[]
        for t in scales:
            def outputs(*scores):
                vals=[]
                for z in probes:
                    m=mp.mpf(1); delta=z
                    for score in scores:
                        xp=m+delta; xm=m-delta
                        plus=mp.tanh(((score*xp*xp)**order-(score*xp*xm)**order)/2)
                        minus=mp.tanh(((score*xm*xp)**order-(score*xm*xm)**order)/2)
                        m,delta=m+delta*(plus+minus)/2,delta*(plus-minus)/2
                    vals.append(m)
                return mp.matrix(vals)
            J=mp.matrix(depth,depth)
            for i in range(depth):
                def f(a):
                    scores=[t*t]*depth; scores[i]=a
                    return outputs(*scores)
                col=mp.diff(f,t*t)*mp.sqrt(2)*t
                J[:,i]=col
            _,s,_=mp.svd(J)
            sigmas.append([float(x) for x in s])
            tied.append(float(mp.norm(sum((J[:,i] for i in range(depth)),mp.zeros(depth,1)))))
        slope=[math.log(sigmas[-1][j]/sigmas[-2][j])/math.log(float(scales[-1]/scales[-2])) for j in range(depth)]
        tied_slope=math.log(tied[-1]/tied[-2])/math.log(float(scales[-1]/scales[-2]))
        result.append(dict(depth=depth,normalizer_order=order,predicted_orders=[2*order*3**j-1 for j in range(depth)],
                            observed_orders=slope,scales=[float(t) for t in scales],singular_values=sigmas,
                            exact_zero_gauge_count=depth,tied_norms=tied,tied_order=tied_slope))
        print('scalar spectrum',order,depth,slope,'tied',tied_slope,flush=True)
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parents[1]/'recomputed')
    args=parser.parse_args()
    args.output_dir.mkdir(parents=True,exist_ok=True)
    data={'versions':{'mpmath':mp.__version__},'scalar_spectra':scalar_jacobian_spectrum()}
    (args.output_dir/'side_results.json').write_text(json.dumps(data,indent=2)+'\n')
