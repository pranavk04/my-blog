"""Recompute the four noise levels with the original 400 common normal draws."""
import argparse, json
from pathlib import Path
import mpmath as mp
import numpy as np

def run():
    result={'mpmath_version':mp.__version__,'numpy_version':np.__version__}
    # Actual scalar two-token oracle inverse: first layer known, q2=k2=w >= 0.
    # Analytic derivative bounds below certify the entire c-interval algebraically.
    mp.mp.dps=100
    t=mp.mpf('.1'); m0=mp.mpf(1); z0=mp.mpf('.5')
    yp=m0+z0*mp.tanh(t*t*z0*(m0+z0))
    ym=m0+z0*mp.tanh(t*t*z0*(m0-z0))
    m=(yp+ym)/2;z=(yp-ym)/2
    W=mp.mpf('.3'); B=m*z*z; A=B/mp.cosh(W*W*z*(m+z))**2
    def f(c):
        return m+z*(mp.tanh(c*z*(m+z))+mp.tanh(c*z*(m-z)))/2
    def inverse_mean(y):
        lo=mp.mpf(0); hi=W*W
        if y<=f(lo):return lo
        if y>=f(hi):return hi
        for _ in range(75):
            mid=(lo+hi)/2
            if f(mid)<y:lo=mid
            else:hi=mid
        return (lo+hi)/2
    deriv_checks=[]
    for j in range(21):
        c=W*W*j/20
        derivative=mp.diff(f,c)
        assert A<=derivative<=B*(1+mp.mpf('1e-90'))
        deriv_checks.append(float(derivative/B))
    rng=np.random.default_rng(20261001)
    normal_draws=rng.standard_normal(400)
    sim=[]
    for ratio_noise in ('.01','.1','1','10'):
        tau=B*t*t*mp.mpf(ratio_noise)
        errors=[mp.sqrt(inverse_mean(f(t*t)+tau*mp.mpf(str(e))))-t for e in normal_draws]
        errs=[e*e for e in errors]
        bias=sum(errors)/len(errors)
        mse=sum(errs)/len(errs)
        sim.append({'tau_over_B_t_squared':ratio_noise,'tau':mp.nstr(tau,25),'Monte_Carlo_MSE_400_draws':mp.nstr(mse,25),'Monte_Carlo_bias_400_draws':mp.nstr(bias,25),'Monte_Carlo_centered_MSE_400_draws':mp.nstr(mse-bias*bias,25)})
    result['oracle_inverse']={'depth':2,'t':str(t),'original_mean':str(m0),'original_half_spread':str(z0),'known_prefix':True,'last_factor_parameter':'q2=k2=w in [0,W]','W':str(W),'incoming_mean':mp.nstr(m,25),'incoming_half_spread':mp.nstr(z,25),'derivative_bounds':[mp.nstr(A,25),mp.nstr(B,25)],'derivative_ratio_sample_range':[min(deriv_checks),max(deriv_checks)],'independent_noise_draws':400,'seed':20261001,'simulations':sim,'interpretation':'Known prefix and values; estimate the final nonnegative factor from one noisy mean.'}
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parents[1]/'recomputed')
    args=parser.parse_args()
    args.output_dir.mkdir(parents=True,exist_ok=True)
    (args.output_dir/'stats_checks.json').write_text(json.dumps(run(),indent=2)+'\n')
    print('Saved noisy recovery results.',flush=True)
