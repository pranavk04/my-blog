"""Print the paper's numerical summaries and compare a complete replay to data/."""
import argparse
import json
from pathlib import Path

import mpmath as mp

ROOT = Path(__file__).resolve().parents[1]
mp.mp.dps = 130


def read(directory):
    scalar = json.loads((directory / 'side_results.json').read_text())['scalar_spectra'][0]
    native = json.loads((directory / 'new_observability_subspace.json').read_text())
    recovery = json.loads((directory / 'stats_checks.json').read_text())['oracle_inverse']
    return scalar, native, recovery


def summary(directory):
    scalar, native, recovery = read(directory)
    runs = {(r['t'], r['decimal_precision']): r for r in native['runs']}
    assert len(runs) == 12, 'The summary requires all six scales at both precision levels.'
    sv = lambda t, dps: list(map(mp.mpf, runs[t, dps]['nonzero_singular_values']))
    low, high = sv('0.06', 120), sv('0.1', 120)
    fits = [mp.log(b / a) / mp.log(mp.mpf('0.1') / mp.mpf('0.06')) for a, b in zip(low, high)]
    bands = []
    for order, lo, hi in [(0, 0, 16), (1, 16, 28), (5, 28, 40), (17, 40, 52)]:
        bands.append({'order': order, 'multiplicity': hi-lo,
                      'min_fit': float(min(fits[lo:hi])), 'max_fit': float(max(fits[lo:hi]))})
    precision_change = max(abs(a / b - 1) for t in ('0.6', '0.4', '0.25', '0.16', '0.1', '0.06')
                           for a, b in zip(sv(t, 90), sv(t, 120)))
    simulation = [{'alpha': r['tau_over_B_t_squared'], 'tau': r['tau'],
                   'MSE': r['Monte_Carlo_MSE_400_draws'], 'bias': r['Monte_Carlo_bias_400_draws'],
                   'relative_RMSE': float(mp.sqrt(mp.mpf(r['Monte_Carlo_MSE_400_draws'])) / mp.mpf(recovery['t']))}
                  for r in recovery['simulations']]
    return {
        'scalar': {'final_pair_orders': scalar['observed_orders'],
                   'max_order_discrepancy': max(abs(a-b) for a, b in zip(scalar['observed_orders'], [1, 5, 17, 53])),
                   'smallest_positive_value_at_0.02': scalar['singular_values'][-1][-1]},
        'native': {'bands': bands, 'positive_count': 52, 'exact_kernel_count': 44,
                   'max_relative_Frobenius_error_vs_AD': max(r['analytic_native_vs_torch_relative_frobenius_error'] for r in runs.values()),
                   'max_relative_change_90_to_120_digits': mp.nstr(precision_change, 15),
                   'max_angle_sine_at_0.6': runs['0.6', 120]['max_principal_angle_sine'],
                   'max_angle_sine_at_0.06': runs['0.06', 120]['max_principal_angle_sine'],
                   'smallest_positive_value_at_0.06': mp.nstr(low[-1], 15),
                   'float64_cutoff_rank_at_0.06': runs['0.06', 120]['float64_rank_at_relative_1e_10'],
                   'high_precision_cutoff_rank_at_0.06': runs['0.06', 120]['high_precision_rank_at_relative_1e_10']},
        'recovery': {'incoming_mean': recovery['incoming_mean'], 'incoming_half_spread': recovery['incoming_half_spread'],
                     'b': recovery['derivative_bounds'][1], 'draws': 400, 'seed': recovery['seed'], 'simulations': simulation}}


def compare(directory, reference):
    s, n, r = read(directory)
    ss, nn, rr = read(reference)
    differences = {'scalar': [], 'native': [], 'recovery': []}

    def close(group, actual, expected, tolerance):
        a, b = mp.mpf(str(actual)), mp.mpf(str(expected))
        difference = abs(a-b) / abs(b) if b else abs(a-b)
        differences[group].append(difference)
        assert difference < mp.mpf(tolerance), (group, actual, expected, str(difference))

    assert n['fixture'] == nn['fixture'], 'Matrix inputs or weights changed.'
    for a, b in zip(s['singular_values'], ss['singular_values']):
        for x, y in zip(a, b): close('scalar', x, y, '1e-12')
    for x, y in zip(s['observed_orders'], ss['observed_orders']):close('scalar', x, y, '1e-12')
    rows = {(a['t'], a['decimal_precision']): a for a in n['runs']}
    originals = {(a['t'], a['decimal_precision']): a for a in nn['runs']}
    assert rows.keys() == originals.keys(), 'Replay must contain the same scales and precision levels.'
    for key, a in rows.items():
        b = originals[key]
        assert len(a['nonzero_singular_values']) == len(b['nonzero_singular_values']) == 52
        for x, y in zip(a['nonzero_singular_values'], b['nonzero_singular_values']):
            close('native', x, y, '1e-25')
        for x, y in zip(a['principal_angle_sines'], b['principal_angle_sines']):
            close('native', x, y, '1e-25')
        for name in ('float64_rank_at_relative_1e_10', 'high_precision_rank_at_relative_1e_10'):
            assert a[name] == b[name], (key, name)
        # Roundoff in this float64 comparison depends on the local BLAS build.
        assert a['analytic_native_vs_torch_relative_frobenius_error'] < 1e-14
    assert r['seed'] == rr['seed'] and r['independent_noise_draws'] == rr['independent_noise_draws']
    for name in ('incoming_mean', 'incoming_half_spread'):
        close('recovery', r[name], rr[name], '1e-22')
    assert len(r['simulations']) == len(rr['simulations']) == 4
    for a, b in zip(r['simulations'], rr['simulations']):
        for name in ('tau', 'Monte_Carlo_MSE_400_draws', 'Monte_Carlo_bias_400_draws', 'Monte_Carlo_centered_MSE_400_draws'):
            close('recovery', a[name], b[name], '1e-22')
    return {group: mp.nstr(max(values), 12) for group, values in differences.items()}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-dir', type=Path, default=ROOT / 'data')
    parser.add_argument('--compare-to', type=Path)
    args = parser.parse_args()
    result = summary(args.data_dir)
    if args.compare_to:
        result['replay_max_relative_differences'] = compare(args.data_dir, args.compare_to)
    print(json.dumps(result, indent=2))
