"""Regenerate the two paper figures from saved or recomputed results."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import FixedLocator, LogFormatterMathtext, NullLocator
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--data-dir',type=Path,default=ROOT/'data')
parser.add_argument('--output-dir',type=Path,default=ROOT/'figures')
args=parser.parse_args()
OUT = args.output_dir
SCALAR_FILE = args.data_dir / "side_results.json"
MATRIX_FILE = args.data_dir / "new_observability_subspace.json"
RECOVERY_FILE = args.data_dir / "stats_checks.json"
COLORS = {0: "#5C626B", 1: "#0072B2", 5: "#D55E00", 17: "#7654A3", 53: "#00876C"}
MARKERS = {0: "o", 1: "o", 5: "s", 17: "^", 53: "D"}

plt.rcParams.update({
    "font.family": "serif", "font.serif": ["cmr10"], "mathtext.fontset": "cm",
    "axes.formatter.use_mathtext": True, "font.size": 8.5, "axes.titlesize": 9,
    "axes.labelsize": 9, "axes.spines.top": False, "axes.spines.right": False,
    "axes.linewidth": 0.6, "xtick.labelsize": 8, "ytick.labelsize": 8,
    "xtick.major.width": 0.6, "ytick.major.width": 0.6,
    "xtick.direction": "out", "ytick.direction": "out",
    "legend.frameon": False, "legend.fontsize": 8,
    "pdf.fonttype": 42, "ps.fonttype": 42,
    "savefig.facecolor": "white", "figure.facecolor": "white",
})

scalar = next(row for row in json.loads(SCALAR_FILE.read_text())["scalar_spectra"]
              if row["depth"] == 4 and row["normalizer_order"] == 1)
matrix = json.loads(MATRIX_FILE.read_text())
runs = sorted((row for row in matrix["runs"] if row["decimal_precision"] == 120),
              key=lambda row: float(row["t"]))
recovery = json.loads(RECOVERY_FILE.read_text())["oracle_inverse"]
assert len(runs) == 6
assert all(len(row["nonzero_singular_values"]) == 52 for row in runs)
assert matrix["fixture"]["seed"] == 21
assert matrix["exact_source_kernel_count"] == 44
assert recovery["known_prefix"] is True
assert recovery["independent_noise_draws"] == 400
st = np.asarray(scalar["scales"], dtype=float)
ss = np.asarray(scalar["singular_values"], dtype=float)
mt = np.asarray([row["t"] for row in runs], dtype=float)
ms = np.asarray([row["nonzero_singular_values"] for row in runs], dtype=float)
assert np.isfinite(ss).all() and np.isfinite(ms).all()
assert (ss > 0).all() and (ms > 0).all()
assert np.all(ms[:, :-1] >= ms[:, 1:])

def save(fig, name, title):
    OUT.mkdir(parents=True,exist_ok=True)
    fig.savefig(OUT / f"{name}.pdf", metadata={
        "Title": title, "Author": "", "Creator": "make_focused_figures.py",
        "CreationDate": None, "ModDate": None})
    plt.close(fig)
    print(f"Wrote {name}.pdf")

def log_axes(ax, ylabel):
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.xaxis.set_minor_locator(NullLocator())
    ax.yaxis.set_minor_locator(NullLocator())
    ax.grid(axis="y", which="major", color="#E7E8EA", linewidth=0.5, zorder=0)
    ax.set_ylabel(ylabel, labelpad=3)
    ax.yaxis.set_major_formatter(LogFormatterMathtext())
    ax.tick_params(pad=2.5, length=3)

def draw_native(ax):
    log_axes(ax, r"Positive singular value $\sigma_j$")
    ax.set_xlabel(r"Query/key amplitude $t$", labelpad=3)
    ax.set_xlim(0.05, 0.71)
    ax.set_ylim(1e-30, 50)
    ax.set_xticks([0.06, 0.1, 0.25, 0.6], ["0.06", "0.10", "0.25", "0.60"])
    ax.yaxis.set_major_locator(FixedLocator([10.0**p for p in [-30, -24, -18, -12, -6, 0]]))
    handles = []
    start = 0
    for order, count in [(0, 16), (1, 12), (5, 12), (17, 12)]:
        band = ms[:, start:start+count]
        for j in range(count):
            ax.plot(mt, band[:, j], color=COLORS[order], lw=0.48, alpha=0.58,
                    marker=MARKERS[order], markersize=1.5, markeredgewidth=0, zorder=2)
        handles.append(Line2D([], [], color=COLORS[order], lw=1.35,
                              marker=MARKERS[order], markersize=3,
                              label=fr"$\beta={order}$ ({count})"))
        start += count
    ax.plot(mt, 1e-10 * ms[:, 0], ":", lw=1.1, color="#272B30", zorder=4)
    ax.text(0.063, 1.0e-10, r"$10^{-10}\sigma_1$ threshold", fontsize=7.5,
            color="#33383D", va="top", ha="left")
    ax.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5, -0.255),
              ncol=2, handlelength=2.2, columnspacing=1.2,
              labelspacing=0.45, borderaxespad=0)

# Main numerical figure: native Jacobian and one existing noisy inverse.
fig, (a, b) = plt.subplots(1, 2, figsize=(6.90, 3.48))
fig.subplots_adjust(left=0.096, right=0.982, bottom=0.255, top=0.855, wspace=0.39)
draw_native(a)
a.set_title("(a) Complete native spectrum", loc="left", pad=19)
a.text(0, 1.025, r"$d=4,\ D=3,\ r=2$; seed 21", transform=a.transAxes,
       fontsize=8, color="#555B63", va="bottom")
log_axes(b, r"Relative recovery error $\mathrm{RMSE}(w)/w_*$")
alpha = np.asarray([float(row["tau_over_B_t_squared"]) for row in recovery["simulations"]])
truth = float(recovery["t"])
mse = np.asarray([float(row["Monte_Carlo_MSE_400_draws"]) for row in recovery["simulations"]])
rmse = np.sqrt(mse) / truth
b.plot(alpha, rmse, "o-", color=COLORS[1], ms=4.5, lw=1.0, zorder=3)
b.axhline(1, ls=":", color="#272B30", lw=0.9)
b.set(xlim=(0.006, 17), ylim=(0.0025, 3.8))
b.set_xticks([0.01, 0.1, 1, 10], ["0.01", "0.1", "1", "10"])
b.yaxis.set_major_locator(FixedLocator([0.01, 0.1, 1]))
b.set_xlabel(r"Output-noise ratio $\alpha=\tau/(b w_*^2)$", labelpad=3)
b.set_title("(b) One-parameter recovery", loc="left", pad=19)
b.text(0, 1.025, "Known prefix and values; estimate final factor",
       transform=b.transAxes, fontsize=8, color="#555B63", va="bottom")
b.text(0.035, 0.985, r"$q_2=k_2=w\in[0,0.3],\quad w_*=0.1$"
       "\n400 Gaussian draws per level", transform=b.transAxes,
       fontsize=8, va="top", linespacing=1.35)
b.text(0.5, -0.282, r"Final score $c_2=w^2$; $b=1.5663\times10^{-6}$"
       "\nSingle observed output mean", transform=b.transAxes,
       ha="center", va="top", fontsize=8, linespacing=1.6)
save(fig, "focused-native-recovery", "Native attention spectrum and a known-prefix noisy inverse")

# Supplementary scalar spectrum. No scalar band is discarded or relabeled.
fig, ax = plt.subplots(figsize=(3.38, 3.20))
fig.subplots_adjust(left=0.19, right=0.965, bottom=0.25, top=0.87)
log_axes(ax, r"Positive singular value $\sigma_j$")
ax.set_xlabel(r"Query/key amplitude $t$", labelpad=3)
ax.set_title("Scalar softmax, depth 4", loc="left", pad=18)
ax.text(0, 1.025, "Fixed values; four positive directions", transform=ax.transAxes,
        fontsize=8, color="#555B63", va="bottom")
ax.set_xlim(0.0175, 0.092)
ax.set_ylim(1e-100, 2)
ax.set_xticks([0.02, 0.04, 0.08], ["0.02", "0.04", "0.08"])
ax.yaxis.set_major_locator(FixedLocator([10.0**p for p in [-100, -80, -60, -40, -20, 0]]))
sx = np.geomspace(st.min(), st.max(), 160)
handles = []
for j, order in enumerate([1, 5, 17, 53]):
    anchor = int(np.argmin(st))
    ax.plot(sx, ss[anchor, j] * (sx / st[anchor])**order, "--", lw=0.95,
            color=COLORS[order], alpha=0.78)
    ax.plot(st, ss[:, j], linestyle="none", marker=MARKERS[order], markersize=4.0,
            markeredgewidth=0.65, color=COLORS[order], zorder=3)
    handles.append(Line2D([], [], marker=MARKERS[order], linestyle="--", lw=0.9,
                          markersize=4, color=COLORS[order], label=fr"$\beta={order}$"))
ax.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5, -0.25), ncol=2,
          handlelength=2.2, columnspacing=1.45, labelspacing=0.45, borderaxespad=0)
save(fig, "focused-scalar-spectrum", "Supplementary fixed-value scalar attention spectrum")

print("No experiments were run.")
for path in (SCALAR_FILE, MATRIX_FILE, RECOVERY_FILE):
    print(f"Input SHA256 {hashlib.sha256(path.read_bytes()).hexdigest()}  {path.name}")
print("Scalar final-pair orders:", scalar["observed_orders"])
print("Recovery relative RMSE:", rmse.tolist())
for order, lo, hi in [(0, 0, 16), (1, 16, 28), (5, 28, 40), (17, 40, 52)]:
    fitted = np.log(ms[1, lo:hi] / ms[0, lo:hi]) / np.log(mt[1] / mt[0])
    print(f"Matrix order {order}, multiplicity {hi-lo}: {fitted.min():.9f} .. {fitted.max():.9f}")
