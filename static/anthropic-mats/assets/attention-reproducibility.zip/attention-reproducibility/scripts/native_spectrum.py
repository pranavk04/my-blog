"""High-precision native width-four contact-band attribution.

Reuses the original seed-21, 48-sequence float64 fixture exactly. The softmax
derivative is evaluated analytically in arbitrary precision in 52 gauge-slice
coordinates, then composed with the complete 52-by-96 native differential.
No finite differences and no threshold-defined native kernel are used.
"""
from pathlib import Path
import argparse, json, time
import mpmath as mp
import numpy as np
import torch

ROOT=Path(__file__).resolve().parents[1]
torch.set_default_dtype(torch.float64)
torch.set_num_threads(2)

def E(r,c,m=4,n=4):
    out=mp.zeros(m,n);out[r,c]=1;return out

def exact_binary_matrix(rows):
    return mp.matrix([[mp.mpf(float(v)) for v in row] for row in rows])

def tangent_bases(U,W):
    # q variations in bottom two rows + every k variation; Q_top is invertible.
    return [[E(a,b,4,2)*w.T for a in [2,3] for b in range(2)] +
            [u*E(a,b,4,2).T for a in range(4) for b in range(2)] for u,w in zip(U,W)]

def source_map(t,U,W):
    T=mp.zeros(52,96)
    for col in range(96):
        layer,off=divmod(col,32)
        dV=E((off-16)//4,(off-16)%4) if off>=16 else mp.zeros(4)
        if off>=16:
            for a in range(4):
                for b in range(4):T[4*a+b,col]=dV[a,b]
        for j in range(3):
            dQ=E(off//2,off%2,4,2) if layer==j and off<8 else mp.zeros(4,2)
            dK=E((off-8)//2,(off-8)%2,4,2) if layer==j and 8<=off<16 else mp.zeros(4,2)
            if layer<j and off>=16:
                dQ+=t*dV.T*U[j];dK+=t*dV.T*W[j]
            A=U[j][:2,:]**-1*dQ[:2,:]
            qhat=dQ-U[j]*A;khat=dK+W[j]*A.T
            coeff=[qhat[a,b] for a in [2,3] for b in range(2)]+[khat[a,b] for a in range(4) for b in range(2)]
            for k,value in enumerate(coeff):T[16+12*j+k,col]=value
    return T

def exact_gauge_columns(t,U,W):
    cols=[]
    def put(vec,layer,offset,M):
        for a in range(M.rows):
            for b in range(M.cols):vec[32*layer+offset+a*M.cols+b]=M[a,b]
    for j in range(3):
        for a in range(2):
            for b in range(2):
                A=E(a,b,2,2);v=mp.zeros(96,1)
                put(v,j,0,U[j]*A);put(v,j,8,-W[j]*A.T);cols.append(v)
    for j in range(2):
        for a in range(4):
            for b in range(4):
                H=E(a,b);v=mp.zeros(96,1)
                put(v,j,16,H);put(v,j+1,16,-H)
                put(v,j+1,0,-t*H.T*U[j+1]);put(v,j+1,8,-t*H.T*W[j+1]);cols.append(v)
    K=mp.zeros(96,44)
    for j,v in enumerate(cols):K[:,j]=v
    return K

def forward_frame(X,Ms,Hs,t):
    deriv=[]
    for layer,M in enumerate(Ms):
        logits=X*M*X.T
        A=mp.matrix([[mp.exp(logits[a,b]) for b in range(4)] for a in range(4)])
        for a in range(4):
            den=sum(A[a,b] for b in range(4))
            for b in range(4):A[a,b]/=den
        new=[]
        for p in range(12*(layer+1)):
            dX=deriv[p] if p<len(deriv) else mp.zeros(4)
            dM=t*Hs[layer][p-12*layer] if p>=12*layer else mp.zeros(4)
            dZ=dX*M*X.T + X*dM*X.T + X*M*dX.T
            dA=mp.zeros(4)
            for a in range(4):
                avg=sum(A[a,b]*dZ[a,b] for b in range(4))
                for b in range(4):dA[a,b]=A[a,b]*(dZ[a,b]-avg)
            new.append(dA*X+A*dX)
        X=A*X;deriv=new
    F=mp.zeros(16,52)
    for a in range(4):
        for b in range(4):
            for token in range(4):F[4*token+a,4*a+b]=X[token,b]
    for p,dX in enumerate(deriv):
        for a in range(4):
            for b in range(4):F[4*a+b,16+p]=dX[a,b]
    return F

def torch_native(fix,t):
    X=torch.tensor(np.array(fix['X'],dtype=float))
    U=[torch.tensor(np.array(x,dtype=float)) for x in fix['U']]
    W=[torch.tensor(np.array(x,dtype=float)) for x in fix['W']]
    def forward(p):
        x=X
        for j in range(3):
            off=32*j;Q=p[off:off+8].reshape(4,2);K=p[off+8:off+16].reshape(4,2);V=p[off+16:off+32].reshape(4,4)
            logits=(x@Q)@(x@K).transpose(-1,-2)
            y=torch.softmax(logits,-1)@x@V.T
            x=y
        return x.flatten()
    p=torch.cat([x.flatten() for j in range(3) for x in (float(t)*U[j],float(t)*W[j],torch.eye(4))])
    return torch.func.jacfwd(forward)(p).detach().numpy()

def run_one(fix,tstr,dps):
    mp.mp.dps=dps;t=mp.mpf(tstr);started=time.time()
    U=[exact_binary_matrix(x) for x in fix['U']];W=[exact_binary_matrix(x) for x in fix['W']]
    Ms=[t*t*u*w.T for u,w in zip(U,W)];Hs=tangent_bases(U,W)
    powers=[0]*16+[1]*12+[5]*12+[17]*12
    F=mp.zeros(768,52)
    for j,x in enumerate(fix['X']):
        F[j*16:(j+1)*16,:]=forward_frame(exact_binary_matrix(x),Ms,Hs,t)
        if (j+1)%12==0:print(json.dumps(dict(phase='frame',t=tstr,dps=dps,bank_done=j+1,seconds=time.time()-started)),flush=True)
    T=source_map(t,U,W);K=exact_gauge_columns(t,U,W)
    gauge_res=mp.norm(T*K)
    # Rank of T certified numerically by positive definite TT^T Cholesky; kernel
    # basis is algebraic, not obtained by thresholding the full native Jacobian.
    mp.cholesky(T*T.T)
    D=mp.diag([t**p for p in powers]);Finv=F*mp.diag([t**(-p) for p in powers])
    print(json.dumps(dict(phase='gram',t=tstr,dps=dps,seconds=time.time()-started)),flush=True)
    Gram=Finv.T*Finv
    R=mp.cholesky(Gram).T
    # Q=Finv R^-1 is orthonormal; J_native=Q R D T. Early40 columns span the
    # first40 Q coordinates; residualized final12 columns span the last12.
    B=R*D*T
    print(json.dumps(dict(phase='eigensystem',t=tstr,dps=dps,seconds=time.time()-started)),flush=True)
    vals,Z=mp.eigsy(B*B.T)
    if min(vals)<=0:raise RuntimeError('Nonpositive eigenvalue at declared precision')
    weak=Z[:,:12]
    sinsq=mp.eigsy(weak[:40,:].T*weak[:40,:],eigvals_only=True)
    angles=[mp.sqrt(max(x,0)) for x in sinsq]
    sv=[mp.sqrt(vals[i]) for i in reversed(range(52))]
    Jmp=F*T
    J64=torch_native(fix,tstr)
    Jround=np.array(Jmp.tolist(),dtype=float)
    relative_native_error=np.linalg.norm(Jround-J64)/np.linalg.norm(Jround)
    s64=np.linalg.svd(J64,compute_uv=False)
    # Independent backward residual for the computed eigensystem.
    A=B*B.T
    eig_res=mp.norm(A*Z-Z*mp.diag(list(vals)))/mp.norm(A)
    record=dict(t=tstr,decimal_precision=dps,nonzero_singular_values=[mp.nstr(x,55) for x in sv],
                max_principal_angle_sine=mp.nstr(max(angles),45),
                principal_angle_sines=[mp.nstr(x,35) for x in angles],
                source_gauge_residual=mp.nstr(gauge_res,12),eigensystem_relative_residual=mp.nstr(eig_res,12),
                analytic_native_vs_torch_relative_frobenius_error=float(relative_native_error),
                float64_rank_at_relative_1e_10=int(sum(s64>s64[0]*1e-10)),
                high_precision_rank_at_relative_1e_10=sum(x>sv[0]*mp.mpf('1e-10') for x in sv),
                elapsed_seconds=time.time()-started,
                quotient_frame_pivot_determinants=[mp.nstr(mp.det(u[:2,:]),20) for u in U])
    print(json.dumps(dict(phase='complete',t=tstr,dps=dps,max_sin=record['max_principal_angle_sine'],seconds=record['elapsed_seconds'])),flush=True)
    return record


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--scales',nargs='+',default=['0.6','0.4','0.25','0.16','0.1','0.06'])
    parser.add_argument('--dps',type=int,nargs='+',default=[90,120])
    parser.add_argument('--output-dir',type=Path,default=ROOT/'recomputed')
    args=parser.parse_args()
    source=json.loads((ROOT/'data/new_observability_subspace.json').read_text())
    args.output_dir.mkdir(parents=True,exist_ok=True)
    path=args.output_dir/'new_observability_subspace.json'
    data=json.loads(path.read_text()) if path.exists() else {k:v for k,v in source.items() if k!='runs'}
    data.setdefault('runs',[])
    data['versions']={'mpmath':mp.__version__,'numpy':np.__version__,'torch':torch.__version__}
    fix=source['fixture']
    for dps in args.dps:
        for scale in args.scales:
            row=run_one(fix,scale,dps)
            data['runs']=[r for r in data['runs'] if (r['t'],r['decimal_precision'])!=(scale,dps)]+[row]
            path.write_text(json.dumps(data,indent=2)+'\n')
    print('saved',path.name,flush=True)

if __name__=='__main__':main()
