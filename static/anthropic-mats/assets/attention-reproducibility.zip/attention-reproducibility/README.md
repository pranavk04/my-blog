# Reproducing the numerical results

This archive contains the experiments used in Section 6 and Appendix F of *Identifiability and Observability of Deep Normalized Attention*. All inputs are synthetic. The scripts evaluate prescribed weights; they do not train a model or download data.

## Setup

Use Python 3.13 and the versions in `requirements.txt`:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

Run the commands below from the archive's top directory. The computations use the CPU; no GPU is needed. The complete replay was checked with Python 3.13.12 on macOS arm64. The twelve matrix runs take approximately two minutes in that environment. PyTorch uses two CPU threads. Timing and float64 roundoff can differ across machines.

## Reproduce the results

```sh
python scripts/scalar_spectrum.py
python scripts/native_spectrum.py
python scripts/recovery.py
python scripts/report_results.py --data-dir recomputed --compare-to data
python scripts/make_figures.py --data-dir recomputed --output-dir recomputed/figures
```

The scripts write to `recomputed/`, preserving the supplied results in `data/`. The report prints the slopes, singular values, precision comparison, automatic-differentiation discrepancy, subspace angles, cutoff ranks, and recovery statistics reported in the paper. It also checks the replay against the saved numerical records. `make_figures.py` writes the two vector PDFs used in the manuscript.

To regenerate the figures and numerical summaries directly from the saved results:

```sh
python scripts/report_results.py
python scripts/make_figures.py
```

## Files and experiment settings

| Script and saved data | Calculation |
|---|---|
| `scripts/scalar_spectrum.py`, `data/side_results.json` | Depth-four scalar softmax, fixed unit values, two-token means at half-spreads 0.45, 0.65, 0.85, 1.05. Query/key amplitude 0.08, 0.04, 0.02; 110 decimal digits. The four positive native singular values have predicted orders 1, 5, 17, 53. |
| `scripts/native_spectrum.py`, `data/new_observability_subspace.json` | Width four, head width two, depth three; 48 four-token inputs, seed 21. All 96 native parameters are differentiated. The same stored binary64 inputs and weights are promoted exactly to 90 and 120 digits at amplitudes 0.6, 0.4, 0.25, 0.16, 0.1, 0.06. The script separates 44 algebraic kernel directions and computes all 52 positive singular values. |
| `scripts/recovery.py`, `data/stats_checks.json` | Known depth-one prefix with query/key factors 0.1 and unit values, input (1.5, 0.5). The final balanced factor lies in [0, 0.3], with truth 0.1. Inversion uses clipping and 75 bisection steps at 100 digits. The four noise ratios reuse the same 400 independent standard-normal draws from NumPy seed 20261001. |
| `scripts/report_results.py` | Computes the main-text and appendix numerical summaries from the three result files. |
| `scripts/make_figures.py` | Draws `figures/focused-native-recovery.pdf` (Figure 1) and `figures/focused-scalar-spectrum.pdf` (the appendix scalar figure). |

The matrix data contains the full input and weight fixture as round-trip decimal strings. The replay reads this fixture instead of drawing it again. Tokens are rows in the implementation and columns in the manuscript. The score has no additional inverse-square-root head-width multiplier.

Scalar singular values are stored as binary64 summaries of 110-digit computations; matrix singular values retain 55 significant digits. The precision comparison and kernel separation are numerical checks, not interval certificates. See Appendix F for the derivative formulas, parameter metric, subspace comparison, noise normalization, and estimator definitions.
